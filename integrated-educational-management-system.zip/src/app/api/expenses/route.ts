import { NextResponse } from "next/server";
import { db } from "@/db";
import { expenses } from "@/db/schema";
import { ensureDb } from "@/lib/ensure-db";
import { desc, eq } from "drizzle-orm";

export async function GET(req: Request) {
  await ensureDb();
  const url = new URL(req.url);
  const year = url.searchParams.get("year");
  let rows = await db.select().from(expenses).orderBy(desc(expenses.id));
  if (year) rows = rows.filter(r=>r.academicYear===year);
  return NextResponse.json(rows);
}
export async function POST(req: Request) {
  await ensureDb();
  const b = await req.json();
  const all = await db.select().from(expenses);
  const voucherNo = b.voucherNo || `EV-${b.academicYear||"2026"}-${String(all.length+1).padStart(5,"0")}`;
  const [row] = await db.insert(expenses).values({
    voucherNo, expenseDate: b.expenseDate, wing: b.wing||"General", paidTo: b.paidTo, category: b.category,
    description: b.description||"", amount: Number(b.amount||0), paymentMode: b.paymentMode||"Cash", academicYear: b.academicYear||"2026",
  }).returning();
  return NextResponse.json(row, { status: 201 });
}
export async function DELETE(req: Request) {
  await ensureDb();
  const url = new URL(req.url); const id = url.searchParams.get("id");
  if (id) await db.delete(expenses).where(eq(expenses.id, Number(id)));
  return NextResponse.json({ ok: true });
}
