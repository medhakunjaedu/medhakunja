import { NextResponse } from "next/server";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { ensureDb } from "@/lib/ensure-db";

export async function GET() {
  await ensureDb();
  const rows = await db.select().from(settings);
  const obj: Record<string,string> = {};
  rows.forEach(r=>{ obj[r.key]=r.value; });
  return NextResponse.json(obj);
}
export async function POST(req: Request) {
  await ensureDb();
  const b = await req.json();
  for (const [k,v] of Object.entries(b)) {
    const existing = await db.select().from(settings);
    const found = existing.find(r=>r.key===k);
    if (found) { const { eq } = await import("drizzle-orm"); await db.update(settings).set({ value: String(v) }).where(eq(settings.key,k)); }
    else await db.insert(settings).values({ key:k, value:String(v) });
  }
  const rows = await db.select().from(settings);
  const obj: Record<string,string> = {}; rows.forEach(r=>{ obj[r.key]=r.value; });
  return NextResponse.json(obj);
}
