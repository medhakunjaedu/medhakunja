import { NextResponse } from "next/server";
import { cookies } from "next/headers";
export async function GET() {
  const c = await cookies();
  const v = c.get("mk_session")?.value;
  if (!v) return NextResponse.json({ authenticated: false }, { status: 401 });
  try { const email = Buffer.from(v, "base64").toString(); return NextResponse.json({ authenticated: true, email, name: "Principal / Admin" }); }
  catch { return NextResponse.json({ authenticated: false }, { status: 401 }); }
}
