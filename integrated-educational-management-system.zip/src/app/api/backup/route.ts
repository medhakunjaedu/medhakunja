import { NextResponse } from "next/server";
import { db } from "@/db";
import { students, payments, paymentItems, expenses, settings } from "@/db/schema";
import { ensureDb } from "@/lib/ensure-db";
export async function GET() {
  await ensureDb();
  const [s,p,pi,e,st] = await Promise.all([db.select().from(students), db.select().from(payments), db.select().from(paymentItems), db.select().from(expenses), db.select().from(settings)]);
  return NextResponse.json({ exportedAt: new Date().toISOString(), students:s, payments:p, paymentItems:pi, expenses:e, settings: st.map(x=>({key:x.key, hasValue: !!x.value})) });
}
