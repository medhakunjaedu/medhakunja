import { NextResponse } from "next/server";
import { db } from "@/db";
import { students } from "@/db/schema";
import { ensureDb } from "@/lib/ensure-db";
import { eq, desc } from "drizzle-orm";

export async function GET(req: Request) {
  await ensureDb();
  const url = new URL(req.url);
  const year = url.searchParams.get("year");
  let rows = await db.select().from(students).orderBy(desc(students.id));
  if (year) rows = rows.filter(r => r.academicYear === year);
  return NextResponse.json(rows);
}

export async function POST(req: Request) {
  await ensureDb();
  const b = await req.json();
  // Auto-generate Student ID: MK-2026-0001 style per year+wing
  const all = await db.select().from(students);
  const prefix = b.wing === "coaching" ? "MAC" : "MMS";
  const countForYear = all.filter(s => s.academicYear === (b.academicYear||"2026")).length;
  const code = b.studentCode || `${prefix}-${b.academicYear||"2026"}-${String(countForYear+1).padStart(4,"0")}`;
  const [row] = await db.insert(students).values({
    studentCode: code,
    fullName: b.fullName, wing: b.wing||"school", branch: b.branch||"", className: b.className,
    shift: b.shift||"", version: b.version||"", academicYear: b.academicYear||"2026",
    primaryContact: b.primaryContact, secondaryContact: b.secondaryContact||"", whatsapp: b.whatsapp||b.primaryContact,
    email: b.email||"", fatherName: b.fatherName||"", motherName: b.motherName||"", bloodGroup: b.bloodGroup||"",
    presentAddress: b.presentAddress||"", monthlyFee: Number(b.monthlyFee||0), notes: b.notes||"",
    status: "Active", droppedDate: "", droppedReason: "",
  }).returning();
  return NextResponse.json(row, { status: 201 });
}
