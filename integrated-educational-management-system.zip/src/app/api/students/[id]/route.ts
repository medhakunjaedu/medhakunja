import { NextResponse } from "next/server";
import { db } from "@/db";
import { students } from "@/db/schema";
import { ensureDb } from "@/lib/ensure-db";
import { eq } from "drizzle-orm";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  await ensureDb();
  const { id } = await params;
  const b = await req.json();
  const allowed: Record<string, unknown> = {};
  const keys = ["fullName","wing","branch","className","shift","version","academicYear","primaryContact","secondaryContact","whatsapp","email","fatherName","motherName","bloodGroup","presentAddress","monthlyFee","notes","status","droppedDate","droppedReason"];
  for (const k of keys) if (k in b) allowed[k] = k==="monthlyFee" ? Number(b[k]||0) : b[k];
  const [row] = await db.update(students).set(allowed).where(eq(students.id, Number(id))).returning();
  return NextResponse.json(row);
}
export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  await ensureDb();
  const { id } = await params;
  await db.delete(students).where(eq(students.id, Number(id)));
  return NextResponse.json({ ok: true });
}
