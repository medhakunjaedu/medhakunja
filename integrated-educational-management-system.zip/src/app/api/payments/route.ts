import { NextResponse } from "next/server";
import { db } from "@/db";
import { payments, paymentItems, students } from "@/db/schema";
import { ensureDb } from "@/lib/ensure-db";
import { desc, eq } from "drizzle-orm";

export async function GET(req: Request) {
  await ensureDb();
  const url = new URL(req.url);
  const year = url.searchParams.get("year");
  const pays = await db.select().from(payments).orderBy(desc(payments.id));
  const items = await db.select().from(paymentItems);
  const studs = await db.select().from(students);
  const map = new Map(studs.map(s=>[s.id,s]));
  let result = pays.map(p=>({ ...p, items: items.filter(i=>i.paymentId===p.id), student: map.get(p.studentId)||null }));
  if (year) result = result.filter(r=>r.academicYear===year);
  return NextResponse.json(result);
}

export async function POST(req: Request) {
  await ensureDb();
  const b = await req.json();
  const all = await db.select().from(payments);
  const receiptNo = b.receiptNo || `MR-${b.academicYear||"2026"}-${String(all.length+1).padStart(5,"0")}`;
  const items: {category:string;month:string;amount:number;examName?:string}[] = b.items||[];
  const gross = items.reduce((s,i)=>s+Number(i.amount||0),0);
  const discount = Number(b.discount||0);
  const total = Math.max(0, gross - discount);
  const examName = b.examName || (items.find(i=>i.category==="Exam Fee")?.examName||"");
  const [row] = await db.insert(payments).values({
    receiptNo, studentId: Number(b.studentId), postingDate: b.postingDate, academicYear: b.academicYear||"2026",
    feeMonths: b.feeMonths||items.map(i=>i.month).filter(Boolean).join(", "), discount, totalAmount: total, grossAmount: gross,
    remainingDue: Number(b.remainingDue||0), paymentMode: b.paymentMode||"Cash", transactionId: b.transactionId||"", examName,
  }).returning();
  for (const it of items) {
    await db.insert(paymentItems).values({ paymentId: row.id, category: it.category, month: it.month||b.feeMonths||"", amount: Number(it.amount||0), examName: it.category==="Exam Fee" ? (it.examName||examName) : "" });
  }
  const savedItems = await db.select().from(paymentItems).where(eq(paymentItems.paymentId,row.id));
  const [stu] = await db.select().from(students).where(eq(students.id,row.studentId));
  return NextResponse.json({ ...row, items: savedItems, student: stu||null }, { status: 201 });
}
