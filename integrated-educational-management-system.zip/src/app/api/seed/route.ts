import { NextResponse } from "next/server";
import { db } from "@/db";
import { students, payments, paymentItems, expenses } from "@/db/schema";
import { ensureDb } from "@/lib/ensure-db";

export async function POST() {
  await ensureDb();
  const existing = await db.select().from(students);
  if (existing.length > 0) return NextResponse.json({ message: "Data already exists", count: existing.length });
  const year = "2026";
  const seedStudents = [
    { studentCode:"MMS-2026-0001", fullName:"Ayesha Rahman", wing:"school", branch:"", className:"KG", shift:"Morning Shift", version:"", primaryContact:"01712345678", secondaryContact:"01812345678", whatsapp:"01712345678", email:"ayesha.parent@gmail.com", fatherName:"Md. Rahman Uddin", motherName:"Fatema Begum", bloodGroup:"O+", presentAddress:"Mohammadpur, Dhaka", monthlyFee:3500 },
    { studentCode:"MMS-2026-0002", fullName:"Tanvir Hasan", wing:"school", branch:"", className:"Class 5", shift:"", version:"Bangla Version", primaryContact:"01722345678", secondaryContact:"", whatsapp:"01722345678", email:"tanvir.parent@gmail.com", fatherName:"Abdul Hasan", motherName:"Nasrin Akter", bloodGroup:"B+", presentAddress:"Tajmahal Road, Mohammadpur", monthlyFee:4500 },
    { studentCode:"MMS-2026-0003", fullName:"Nusrat Jahan", wing:"school", branch:"", className:"Class 8", shift:"", version:"English Version", primaryContact:"01732345678", secondaryContact:"", whatsapp:"01732345678", email:"nusrat.parent@gmail.com", fatherName:"Jahan Alam", motherName:"Shirin Sultana", bloodGroup:"A+", presentAddress:"Block-C, Mohammadpur", monthlyFee:6000 },
    { studentCode:"MMS-2026-0004", fullName:"Ariful Islam", wing:"school", branch:"", className:"Class 10", shift:"", version:"Bangla Version", primaryContact:"01742345678", secondaryContact:"", whatsapp:"01742345678", email:"", fatherName:"Islam Uddin", motherName:"Rokeya Begum", bloodGroup:"AB+", presentAddress:"Mohammadpur, Dhaka", monthlyFee:6500 },
    { studentCode:"MAC-2026-0001", fullName:"Sakib Chowdhury", wing:"coaching", branch:"9/17, Block-C, Tajmahal Road, Mohammadpur, Dhaka-1207", className:"Class 9", shift:"", version:"Bangla Version", primaryContact:"01752345678", secondaryContact:"", whatsapp:"01752345678", email:"sakib@gmail.com", fatherName:"Chowdhury Ahmed", motherName:"Laila Chowdhury", bloodGroup:"O-", presentAddress:"Mohammadpur", monthlyFee:5000 },
    { studentCode:"MAC-2026-0002", fullName:"Mim Akter", wing:"coaching", branch:"15/15, Block-C, Tajmahal Road, Mohammadpur, Dhaka-1207", className:"Intermediate 1st Year", shift:"", version:"English Version", primaryContact:"01762345678", secondaryContact:"", whatsapp:"01762345678", email:"mim@gmail.com", fatherName:"Akter Hossain", motherName:"Mina Begum", bloodGroup:"B-", presentAddress:"Tajmahal Road", monthlyFee:7000 },
    { studentCode:"MAC-2026-0003", fullName:"Rifat Karim", wing:"coaching", branch:"9/17, Block-C, Tajmahal Road, Mohammadpur, Dhaka-1207", className:"Intermediate 2nd Year", shift:"", version:"Bangla Version", primaryContact:"01772345678", secondaryContact:"", whatsapp:"01772345678", email:"rifat@gmail.com", fatherName:"Karim Sheikh", motherName:"Amina Khatun", bloodGroup:"A-", presentAddress:"Mohammadpur", monthlyFee:7500 },
    { studentCode:"MMS-2026-0005", fullName:"Farhan Ahmed", wing:"school", branch:"", className:"Class 3", shift:"", version:"English Version", primaryContact:"01782345678", secondaryContact:"", whatsapp:"01782345678", email:"farhan@gmail.com", fatherName:"Ahmed Ali", motherName:"Sara Ahmed", bloodGroup:"O+", presentAddress:"Mohammadpur", monthlyFee:5000 },
  ];
  const inserted = [];
  for (const s of seedStudents) {
    const [row] = await db.insert(students).values({ ...s, academicYear: year, status:"Active", droppedDate:"", droppedReason:"", notes:"" }).returning();
    inserted.push(row);
  }
  const today = new Date().toISOString().slice(0,10);
  const ym = today.slice(0,7);
  const monthName = ["January","February","March","April","May","June","July","August","September","October","November","December"][new Date().getMonth()];
  // payments for first 6 students
  let r = 1;
  for (const stu of inserted.slice(0,6)) {
    const isExam = stu.className.includes("Class 9") || stu.className.includes("Class 10") || stu.className.includes("Intermediate");
    const items = [{ category:"Tuition Fee", month: monthName, amount: stu.monthlyFee, examName:"" }];
    if (isExam) items.push({ category:"Exam Fee", month: monthName, amount: 800, examName:"1st Terminal Exam 2026" });
    const gross = items.reduce((a,i)=>a+i.amount,0);
    const [pay] = await db.insert(payments).values({ receiptNo:`MR-2026-${String(r).padStart(5,"0")}`, studentId: stu.id, postingDate: today, academicYear: year, feeMonths: monthName, discount:0, totalAmount:gross, grossAmount:gross, remainingDue:0, paymentMode: r%3===0?"bKash": r%3===1?"Cash":"Nagad", transactionId: r%3===0?"BKX"+1000+r:"", examName: isExam?"1st Terminal Exam 2026":"" }).returning();
    for (const it of items) await db.insert(paymentItems).values({ paymentId: pay.id, category: it.category, month: it.month, amount: it.amount, examName: it.examName });
    r++;
  }
  const exps = [
    { voucherNo:"EV-2026-00001", expenseDate: today, wing:"School", paidTo:"Landlord - Mohammadpur Property", category:"House Rent", description:"Monthly house rent - School campus", amount:45000, paymentMode:"Bank Transfer" },
    { voucherNo:"EV-2026-00002", expenseDate: today, wing:"General", paidTo:"DESCO / Utility", category:"Utility Bills", description:"Electricity & water bill", amount:8500, paymentMode:"bKash" },
    { voucherNo:"EV-2026-00003", expenseDate: `${ym}-05`, wing:"Academic Care", paidTo:"Stationery Shop", category:"Stationary", description:"Notebooks, pens & printing papers", amount:3200, paymentMode:"Cash" },
  ];
  for (const e of exps) await db.insert(expenses).values({ ...e, academicYear: year });
  return NextResponse.json({ ok:true, students: inserted.length });
}
